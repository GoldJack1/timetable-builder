(function () {
  function formatWhen(iso, letter, name) {
    var label = iso;
    var parts = iso.split("-");
    if (parts.length >= 3) {
      var dt = new Date(+parts[0], +parts[1] - 1, +parts[2]);
      if (!isNaN(dt.getTime())) {
        label = dt.toLocaleDateString(undefined, {
          weekday: "long",
          day: "numeric",
          month: "long",
          year: "numeric",
        });
      }
    }
    if (letter) {
      label += " · " + letter + (name ? " " + name : "");
    }
    return label;
  }

  function paletteName(root, letter) {
    var btn = root.querySelector('[data-kwvr-key="' + letter + '"]');
    if (!btn) return "";
    return btn.textContent.replace(letter, "").trim();
  }

  function closeOverlay(root) {
    var overlay = root.querySelector(".kwvr-tt-overlay");
    if (!overlay) return;
    overlay.hidden = true;
    document.body.classList.remove("kwvr-tt-open");
  }

  function openOverlay(root, iso, letter) {
    var overlay = root.querySelector(".kwvr-tt-overlay");
    if (!overlay) return;
    overlay.hidden = false;
    document.body.classList.add("kwvr-tt-open");
    root.querySelectorAll("[data-kwvr-iso]").forEach(function (el) {
      el.classList.toggle("is-selected", el.getAttribute("data-kwvr-iso") === iso);
    });
    root.querySelectorAll("[data-kwvr-key]").forEach(function (el) {
      el.classList.toggle("is-active", !!letter && el.getAttribute("data-kwvr-key") === letter);
    });
    var empty = overlay.querySelector(".kwvr-tt-overlay-empty");
    var title = overlay.querySelector(".kwvr-tt-overlay-when");
    var shown = false;
    overlay.querySelectorAll("[data-kwvr-panel]").forEach(function (el) {
      var on = !!letter && el.getAttribute("data-kwvr-panel") === letter;
      el.hidden = !on;
      el.classList.toggle("is-active", on);
      if (on) shown = true;
    });
    if (title) title.textContent = formatWhen(iso, letter, paletteName(root, letter));
    if (empty) empty.hidden = shown;
    var closeBtn = overlay.querySelector(".kwvr-tt-overlay-close");
    if (closeBtn) closeBtn.focus();
  }

  document.addEventListener("click", function (e) {
    var close = e.target.closest("[data-kwvr-close]");
    if (close) {
      var root = close.closest(".kwvr-tt-live");
      if (root) closeOverlay(root);
      return;
    }
    var day = e.target.closest("[data-kwvr-iso]");
    if (day) {
      var live = day.closest(".kwvr-tt-live");
      if (!live) return;
      e.preventDefault();
      openOverlay(live, day.getAttribute("data-kwvr-iso") || "", day.getAttribute("data-kwvr-letter") || "");
      return;
    }
    var key = e.target.closest("[data-kwvr-key]");
    if (key) {
      var wrap = key.closest(".kwvr-tt-live");
      if (!wrap) return;
      openOverlay(wrap, "", key.getAttribute("data-kwvr-key") || "");
    }
  });

  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    document.querySelectorAll(".kwvr-tt-live").forEach(closeOverlay);
  });
})();
